﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace ATIVIDADE_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonExercicio1_Click(object sender, EventArgs e)
        {
            int[] Matriz = new int[20];
            string aux = "";
            string valor = "";

            for (var x = 0; x < 20; x++)
            {
                valor = Interaction.InputBox("Digite o Valor da posição " + (x + 1), "Entrada de Dados");
                if (valor == "")
                {
                    break;
                }
                else if (int.TryParse(valor, out Matriz[x]))
                {
                    
                    aux = Matriz[x].ToString() + "\n" + aux;
                }
                else 
                {
                    MessageBox.Show("Número Invalido");
                    x--; 
                }

            }
            MessageBox.Show(aux);
        }

        private void buttonExercicio2_Click(object sender, EventArgs e)
        {

            int[] Matriz = new int[20];
            string aux = "";
            string valor = "";

            for (var x = 0; x < 20; x++)
            {
                valor = Interaction.InputBox("Digite o Valor da posição " + (x + 1), "Entrada de Dados");
                if (valor == "")
                {
                    break;
                }
                else if (!int.TryParse(valor, out Matriz[x]))
                {
                    MessageBox.Show("Número Invalido!!");
                    x--;
                }

            }
            Array.Reverse(Matriz);
            for (var x = 19; x <= 0; x--)
                aux = aux + "\n" + Matriz[x];
            MessageBox.Show(aux);
        }

        private void buttonExercicio3_Click(object sender, EventArgs e)
        {
            double[] qtde = new double[10];
            double[] preco = new double[10];
            double faturamento = 0;
            string valor = "";

            for (var x = 0; x < 2; x++)
            {
                valor = Interaction.InputBox("Digite a quantidade da mercadoria " + (x + 1), "Entrada de Dados");
                if (valor == "")
                {
                    break;
                }
                if (!double.TryParse(valor, out qtde[x]))
                {
                    MessageBox.Show("Valor inválido!");
                    x--;
                }
                else
                {
                    while (true)
                    {
                        valor = Interaction.InputBox("Digite o valor da Mercadoria " + (x + 1) + ":", "Entrada de Dados");
                        if (double.TryParse(valor, out preco[x]))
                            break;
                        else
                            MessageBox.Show("Digite um valor válido para a Mercadoria " + (x + 1));
                    }
                }
                faturamento += qtde[x] * preco[x];
            }
            MessageBox.Show("Faturamento: " + faturamento.ToString("N2"));
        }

        private void buttonExercicio4_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void buttonExercicio5_Click(object sender, EventArgs e)
        {
            ArrayList Alunos = new ArrayList(new string[] {"Ana", "André", "Débora", "Fátima", "João", "Janete","Otávio", "Marcelo", "Pedro", "Thais"});
            Alunos.Remove("Otávio");
            string lista = "";
            foreach (string nome in Alunos)
            {
                lista = lista + nome + "\n";
            }
            MessageBox.Show(lista);
        }

        private void buttonExercicio6_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double medias;
            int x, y;
            string valor, mediaFinal = "";
            for (x = 0; x < 20; x++)
            {
                medias = 0;
                for (y = 0; y < 3; y++)
                {
                    valor = Interaction.InputBox("Nota " + (y + 1) + " do aluno " + (y + 1) + ":", "Entrada das Notas");
                    if (double.TryParse(valor, out notas[x, y]))
                    {
                        medias += notas[x, y];
                    }
                    else
                    {
                        MessageBox.Show("Digite um valor válido para as notas");
                        y--;
                    }
                }
                medias /= 3;
                mediaFinal += "Aluno " + (x + 1) + " : média: " + medias.ToString("N1") + "\n";
            }
            MessageBox.Show(mediaFinal);
        }

        private void buttonExercicio7_Click(object sender, EventArgs e)
        {
            Form frm = Application.OpenForms["Exercicio7"];
            if (frm != null)
            {
                frm.Close();
            }
            Exercicio7 frm2 = new Exercicio7();
            frm2.Show();
        }
    }
}
