﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace ATIVIDADE_7
{
    public partial class Exercicio7 : Form
    {
        public Exercicio7()
        {
            InitializeComponent();
        }

        private void executarExercicio7_Click(object sender, EventArgs e)
        {
            string[] MatrizNome = new string[4];
            int[] MatrizNumCaract = new int[4];
            string valor = "";

            listBoxNomes.Items.Clear();

            for (var x = 0; x < 4; x++)
            {
                valor = Interaction.InputBox("Digite o nome " + (x + 1), "Entrada de Dados");
                if (valor == "")
                {
                    break;
                }
                MatrizNome[x] = valor;
                MatrizNumCaract[x] = valor.Length - valor.Count(Char.IsWhiteSpace);
            }

            for (var i = 0; i < 4; i++)
            {
                listBoxNomes.Items.Add("O nome: " + MatrizNome[i] + " possui " + MatrizNumCaract[i] + " caracteres\n");
            }
        }
    }
}
