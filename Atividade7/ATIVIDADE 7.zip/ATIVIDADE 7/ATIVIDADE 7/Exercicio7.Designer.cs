﻿namespace ATIVIDADE_7
{
    partial class Exercicio7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.executarExercicio7 = new System.Windows.Forms.Button();
            this.listBoxNomes = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // executarExercicio7
            // 
            this.executarExercicio7.Location = new System.Drawing.Point(25, 133);
            this.executarExercicio7.Name = "executarExercicio7";
            this.executarExercicio7.Size = new System.Drawing.Size(120, 60);
            this.executarExercicio7.TabIndex = 0;
            this.executarExercicio7.Text = "Executar";
            this.executarExercicio7.UseVisualStyleBackColor = true;
            this.executarExercicio7.Click += new System.EventHandler(this.executarExercicio7_Click);
            // 
            // listBoxNomes
            // 
            this.listBoxNomes.FormattingEnabled = true;
            this.listBoxNomes.Location = new System.Drawing.Point(192, 27);
            this.listBoxNomes.Name = "listBoxNomes";
            this.listBoxNomes.Size = new System.Drawing.Size(186, 277);
            this.listBoxNomes.TabIndex = 1;
            // 
            // Exercicio7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(396, 394);
            this.Controls.Add(this.listBoxNomes);
            this.Controls.Add(this.executarExercicio7);
            this.Name = "Exercicio7";
            this.Text = "Exercicio7";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button executarExercicio7;
        private System.Windows.Forms.ListBox listBoxNomes;
    }
}