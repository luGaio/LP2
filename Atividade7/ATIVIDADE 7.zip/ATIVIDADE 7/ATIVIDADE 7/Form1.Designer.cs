﻿namespace ATIVIDADE_7
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExercicio1 = new System.Windows.Forms.Button();
            this.buttonExercicio2 = new System.Windows.Forms.Button();
            this.buttonExercicio3 = new System.Windows.Forms.Button();
            this.buttonExercicio4 = new System.Windows.Forms.Button();
            this.buttonExercicio5 = new System.Windows.Forms.Button();
            this.buttonExercicio6 = new System.Windows.Forms.Button();
            this.buttonExercicio7 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonExercicio1
            // 
            this.buttonExercicio1.Location = new System.Drawing.Point(12, 36);
            this.buttonExercicio1.Name = "buttonExercicio1";
            this.buttonExercicio1.Size = new System.Drawing.Size(130, 62);
            this.buttonExercicio1.TabIndex = 0;
            this.buttonExercicio1.Text = "Exercicio 1";
            this.buttonExercicio1.UseVisualStyleBackColor = true;
            this.buttonExercicio1.Click += new System.EventHandler(this.buttonExercicio1_Click);
            // 
            // buttonExercicio2
            // 
            this.buttonExercicio2.Location = new System.Drawing.Point(175, 36);
            this.buttonExercicio2.Name = "buttonExercicio2";
            this.buttonExercicio2.Size = new System.Drawing.Size(130, 62);
            this.buttonExercicio2.TabIndex = 1;
            this.buttonExercicio2.Text = "Exercicio 2";
            this.buttonExercicio2.UseVisualStyleBackColor = true;
            this.buttonExercicio2.Click += new System.EventHandler(this.buttonExercicio2_Click);
            // 
            // buttonExercicio3
            // 
            this.buttonExercicio3.Location = new System.Drawing.Point(12, 114);
            this.buttonExercicio3.Name = "buttonExercicio3";
            this.buttonExercicio3.Size = new System.Drawing.Size(130, 62);
            this.buttonExercicio3.TabIndex = 2;
            this.buttonExercicio3.Text = "Exercicio 3";
            this.buttonExercicio3.UseVisualStyleBackColor = true;
            this.buttonExercicio3.Click += new System.EventHandler(this.buttonExercicio3_Click);
            // 
            // buttonExercicio4
            // 
            this.buttonExercicio4.Location = new System.Drawing.Point(175, 114);
            this.buttonExercicio4.Name = "buttonExercicio4";
            this.buttonExercicio4.Size = new System.Drawing.Size(130, 62);
            this.buttonExercicio4.TabIndex = 3;
            this.buttonExercicio4.Text = "Exercicio 4";
            this.buttonExercicio4.UseVisualStyleBackColor = true;
            this.buttonExercicio4.Click += new System.EventHandler(this.buttonExercicio4_Click);
            // 
            // buttonExercicio5
            // 
            this.buttonExercicio5.Location = new System.Drawing.Point(12, 195);
            this.buttonExercicio5.Name = "buttonExercicio5";
            this.buttonExercicio5.Size = new System.Drawing.Size(130, 62);
            this.buttonExercicio5.TabIndex = 4;
            this.buttonExercicio5.Text = "Exercicio 5";
            this.buttonExercicio5.UseVisualStyleBackColor = true;
            this.buttonExercicio5.Click += new System.EventHandler(this.buttonExercicio5_Click);
            // 
            // buttonExercicio6
            // 
            this.buttonExercicio6.Location = new System.Drawing.Point(175, 195);
            this.buttonExercicio6.Name = "buttonExercicio6";
            this.buttonExercicio6.Size = new System.Drawing.Size(130, 62);
            this.buttonExercicio6.TabIndex = 5;
            this.buttonExercicio6.Text = "Exercicio 6";
            this.buttonExercicio6.UseVisualStyleBackColor = true;
            this.buttonExercicio6.Click += new System.EventHandler(this.buttonExercicio6_Click);
            // 
            // buttonExercicio7
            // 
            this.buttonExercicio7.Location = new System.Drawing.Point(94, 271);
            this.buttonExercicio7.Name = "buttonExercicio7";
            this.buttonExercicio7.Size = new System.Drawing.Size(130, 62);
            this.buttonExercicio7.TabIndex = 6;
            this.buttonExercicio7.Text = "Exercicio 7";
            this.buttonExercicio7.UseVisualStyleBackColor = true;
            this.buttonExercicio7.Click += new System.EventHandler(this.buttonExercicio7_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(317, 345);
            this.Controls.Add(this.buttonExercicio7);
            this.Controls.Add(this.buttonExercicio6);
            this.Controls.Add(this.buttonExercicio5);
            this.Controls.Add(this.buttonExercicio4);
            this.Controls.Add(this.buttonExercicio3);
            this.Controls.Add(this.buttonExercicio2);
            this.Controls.Add(this.buttonExercicio1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonExercicio1;
        private System.Windows.Forms.Button buttonExercicio2;
        private System.Windows.Forms.Button buttonExercicio3;
        private System.Windows.Forms.Button buttonExercicio4;
        private System.Windows.Forms.Button buttonExercicio5;
        private System.Windows.Forms.Button buttonExercicio6;
        private System.Windows.Forms.Button buttonExercicio7;
    }
}

